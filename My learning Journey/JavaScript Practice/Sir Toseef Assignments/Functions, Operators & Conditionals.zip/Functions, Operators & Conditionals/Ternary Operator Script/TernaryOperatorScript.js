let num = prompt("Enter the number")
alert(num >= 0 ? "The number is positive" : "The number is negative")