let num1 = prompt("Enter the first number")
let num2 = prompt("Enter the second number")
console.log(`The first number is ${num1}`);
console.log(`The second number is ${num2}`);

console.log("The numbers are equal:", num1 == num2);
console.log("The numbers are not equal:", num1 != num2);
console.log("The first number is greater than the second one:", num1 > num2);
console.log("The first number is smaller than the second one:", num1 < num2);
console.log("The first number is greater than or equal to the second one:", num1 >= num2);
console.log("The first number is less than or equal to the second one:", num1 <= num2);
