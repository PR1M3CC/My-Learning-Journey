// Task 1: Write a program to add two numbers and log the result to the console.
function addTwoNumbers(num1, num2) {
    return parseInt(num1) + parseInt(num2)
}
console.log(addTwoNumbers(7, 28));
// Task 2: Write a program to subtract two numbers and log the result to the console.
function addTwoNumbers(num1, num2) {
    return num1 - num2
}
console.log(addTwoNumbers(15, 20));
// Task 3: Write a program to multiply two numbers and log the result to the console.
function addTwoNumbers(num1, num2) {
    return num1 * num2
}
console.log(addTwoNumbers(5, 3));
// Task 4: Write a program to divide two numbers and log the result to the console.
function addTwoNumbers(num1, num2) {
    return num1 / num2
}
console.log(addTwoNumbers(25, 5));
// Task 5: Write a program to find the remainder when one number is divided by another and log the result to the console.
function addTwoNumbers(num1, num2) {
    return num1 % num2
}
console.log(addTwoNumbers(25, 4));
// Task 6: Use the + operator to add a number to a variable and log the result to the console.
let a = 45
a = a+5
console.log(a);
// Task 7: Use the operator to subtract a number from a variable and log the result to the console.
let b = 45
b = b-5
console.log(b);