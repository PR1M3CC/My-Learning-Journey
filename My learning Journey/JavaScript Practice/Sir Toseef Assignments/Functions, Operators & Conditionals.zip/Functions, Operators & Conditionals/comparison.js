// Task 8: Write a program to compare two numbers using > and < and log the result to the console.
let num1 = 12
let num2 = 15
if (num1 > num2) {
    console.log(`${num1} is greater than ${num2}`)
}
else if (num1 == num2) {
    console.log(`${num1} is equal to ${num2}`);
}
else{
    console.log(`${num1} is less than ${num2}`);
    
}
// Task 9: Write a program to compare two numbers using > and <= and log the result to the console.
let num3 = 12
let num4 = 15
if (num3 > num4) {
    console.log(`${num1} is greater than ${num2}`)
}
else if (num1 <= num2) {
    console.log(`${num1} is less than or equal to ${num2}`);
}
// Task 10: Write a program to compare two numbers using == and === and log the result to the console.
let num5 = 12
let num6 = 12
if (num5 == num6) {
    console.log(`The first and second variable have the same value but their data type may be different`);
}
else if (num5 === num6) {
    console.log(`The first and second variable have the same value and data type`);
}
else{
    console.log(`The first and second variable do not have the same value`);
}